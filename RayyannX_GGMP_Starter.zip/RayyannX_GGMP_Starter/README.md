# RayyannX GGMP — Login integration

Project Android baru, bukan modifikasi APK lama dan tidak memakai/membypass server GGMP lama.

## Perubahan integrasi login
- Android mengirim `POST /auth/login` dengan `username`, `password`, dan `licenseKey`.
- Tampilan hanya masuk ke halaman PREMIUM setelah backend mengembalikan JWT dan `plan: PREMIUM`.
- Respons 401 ditampilkan sebagai kredensial/key tidak valid; 403 ditampilkan sebagai akun nonaktif/tidak diizinkan.
- Token disimpan sebagai ciphertext AES-256-GCM di SharedPreferences; kunci AES berada di Android Keystore.
- Saat aplikasi dibuka, `POST /auth/me` memvalidasi JWT dan status akun. Token invalid/kedaluwarsa/akun nonaktif dihapus.
- Logout menghapus token lokal. JWT backend tetap berlaku sampai kedaluwarsa (maksimal 12 jam); untuk logout yang mencabut token di server, tambahkan token revocation/session table.

## Konfigurasi Android BASE_URL
Edit `android/app/src/main/java/com/rayyannx/ggmp/AppConfig.kt`:

```kotlin
object AppConfig {
    const val BASE_URL = "https://api.domain-kamu.com/"
}
```

Gunakan domain milik sendiri dengan sertifikat TLS valid. Jangan gunakan HTTP/IP lokal untuk build produksi. Manifest menonaktifkan cleartext traffic. Jangan menonaktifkan validasi sertifikat TLS.

## Menjalankan backend
```bash
cd backend
npm install
ADMIN_USERNAME=owner ADMIN_PASSWORD='GantiPasswordKuat!' npm run bootstrap-admin
JWT_SECRET='buat-random-secret-minimal-32-karakter' npm start
```

Letakkan backend di balik reverse proxy HTTPS (mis. Nginx/Caddy) dan arahkan domain `api.domain-kamu.com` ke proxy. Port Node (default 3000) sebaiknya tidak diekspos langsung ke internet. Atur firewall, backup SQLite, rate limiting, audit log, dan rotasi secret sebelum produksi.

## API
- `POST /auth/login`: `{ "username":"...", "password":"...", "licenseKey":"..." }`
  - `200`: `{ token, username, role, plan:"PREMIUM" }`
  - `401`: username/password atau license key salah/tidak valid
  - `403`: akun nonaktif
- `POST /auth/me`: header `Authorization: Bearer <token>`, body `{}`
  - `200`: `{ username, role, plan:"PREMIUM" }`
  - `401`: token hilang/tidak valid/kedaluwarsa
  - `403`: akun nonaktif
- `POST /admin/keys` (Bearer admin JWT): `{label}`
- `POST /admin/users` (Bearer admin JWT): `{username,password,licenseKey}`
- `POST /admin/users/:id/status` (Bearer admin JWT): `{active:true|false}`

## Uji end-to-end
1. Deploy backend melalui HTTPS dan pastikan `GET https://api.domain-kamu.com/health` menghasilkan `{"ok":true,...}`.
2. Jalankan `bootstrap-admin`, simpan license key admin yang ditampilkan.
3. Login sebagai admin ke API (atau gunakan tool API) lalu buat license key dan user dengan password minimal 10 karakter.
4. Masukkan URL HTTPS yang benar ke `AppConfig.BASE_URL`; sync dan build aplikasi Android.
5. Uji login dengan kredensial/key benar: harus menerima halaman PREMIUM hanya setelah respons server sukses.
6. Uji password salah dan key salah: aplikasi tetap di halaman login dan menampilkan error.
7. Nonaktifkan user melalui endpoint admin, lalu coba login: backend harus mengembalikan 403 dan aplikasi menampilkan pesan akun nonaktif.
8. Login benar, tutup paksa lalu buka aplikasi: aplikasi harus memanggil `/auth/me` dan memulihkan sesi hanya jika server menyatakan aktif.
9. Logout, buka ulang aplikasi: form login harus muncul karena token lokal telah dihapus.
10. Biarkan token kedaluwarsa atau gunakan token rusak: pemeriksaan sesi harus gagal dan token lokal dihapus.

Tidak ada login lokal/demo yang dianggap sukses. Status PREMIUM hanya bersumber dari respons backend.
