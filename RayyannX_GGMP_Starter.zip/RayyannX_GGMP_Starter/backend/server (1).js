const express=require('express'), bcrypt=require('bcryptjs'), jwt=require('jsonwebtoken'),
 crypto=require('crypto'), db=require('./db');
const app=express(); app.use(express.json({limit:'32kb'}));
const SECRET=process.env.JWT_SECRET;
if(!SECRET || SECRET.length<32){console.error('Set JWT_SECRET (32+ chars).');process.exit(1);}
const hashKey=k=>crypto.createHash('sha256').update(String(k)).digest('hex');
function auth(req,res,next){try{req.actor=jwt.verify((req.headers.authorization||'').replace(/^Bearer\s+/i,''),SECRET);next();}catch{res.status(401).json({error:'Unauthorized'});}}
function admin(req,res,next){if(req.actor?.role!=='ADMIN')return res.status(403).json({error:'Admin only'});next();}
app.get('/health',(_,res)=>res.json({ok:true,service:'RayyannX'}));
app.post('/auth/login',(req,res)=>{
 const {username,password,licenseKey}=req.body||{};
 if(!username||!password||!licenseKey)return res.status(400).json({error:'Username, password, key required'});
 const u=db.prepare('SELECT * FROM users WHERE username=?').get(username);
 if(!u||!bcrypt.compareSync(password,u.password_hash))return res.status(401).json({error:'Invalid username or password'});
 if(!u.active)return res.status(403).json({error:'Account inactive'});
 const kh=hashKey(licenseKey), k=db.prepare('SELECT * FROM license_keys WHERE key_hash=? AND revoked=0').get(kh);
 if(!k||kh!==u.license_key_hash)return res.status(401).json({error:'Invalid or revoked license key'});
 res.json({token:jwt.sign({sub:u.id,username:u.username,role:u.role},SECRET,{expiresIn:'12h'}),username:u.username,role:u.role,plan:'PREMIUM'});
});
// Session check: token must still be valid and account must remain active.
app.post('/auth/me',auth,(req,res)=>{
 const u=db.prepare('SELECT id,username,role,active FROM users WHERE id=?').get(req.actor.sub);
 if(!u||!u.active)return res.status(403).json({error:'Account inactive'});
 res.json({username:u.username,role:u.role,plan:'PREMIUM'});
});
app.post('/admin/keys',auth,admin,(req,res)=>{
 const key='RX-'+crypto.randomBytes(18).toString('hex').toUpperCase();
 db.prepare('INSERT INTO license_keys(key_hash,label) VALUES (?,?)').run(hashKey(key),req.body?.label||null);
 res.status(201).json({licenseKey:key,warning:'Copy now; shown only once.'});
});
app.post('/admin/users',auth,admin,async(req,res)=>{
 const {username,password,licenseKey}=req.body||{};
 if(!username||!password||password.length<10||!licenseKey)return res.status(400).json({error:'Username, password (10+ chars), key required'});
 const kh=hashKey(licenseKey), k=db.prepare('SELECT * FROM license_keys WHERE key_hash=? AND revoked=0').get(kh);
 if(!k)return res.status(400).json({error:'Create a valid key first'});
 try{const x=db.prepare("INSERT INTO users(username,password_hash,license_key_hash,role) VALUES (?,?,?,'USER')")
 .run(username,await bcrypt.hash(password,12),kh);res.status(201).json({id:x.lastInsertRowid,username,plan:'PREMIUM',active:true});}
 catch{res.status(409).json({error:'Username already exists'});}
});
app.post('/admin/users/:id/status',auth,admin,(req,res)=>{
 if(typeof req.body?.active!=='boolean')return res.status(400).json({error:'active must be boolean'});
 const x=db.prepare('UPDATE users SET active=? WHERE id=?').run(req.body.active?1:0,req.params.id);
 if(!x.changes)return res.status(404).json({error:'User not found'});
 res.json({ok:true,active:req.body.active});
});
app.listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('RayyannX API listening'));
