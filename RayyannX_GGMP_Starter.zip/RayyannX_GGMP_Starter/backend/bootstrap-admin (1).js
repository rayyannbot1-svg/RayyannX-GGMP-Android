const bcrypt = require('bcryptjs'), crypto = require('crypto'), db = require('./db');
const username = process.env.ADMIN_USERNAME, password = process.env.ADMIN_PASSWORD;
if (!username || !password || password.length < 12) {
 console.error('Set ADMIN_USERNAME and ADMIN_PASSWORD (minimum 12 characters).'); process.exit(1);
}
const key = 'ADMIN-' + crypto.randomBytes(24).toString('hex');
const kh = crypto.createHash('sha256').update(key).digest('hex');
db.prepare('INSERT INTO license_keys(key_hash,label) VALUES (?,?)').run(kh,'Admin bootstrap key');
db.prepare("INSERT INTO users(username,password_hash,license_key_hash,role) VALUES (?,?,?,'ADMIN')")
 .run(username,bcrypt.hashSync(password,12),kh);
console.log('Admin created. Save this one-time license key:',key);
