
package com.rayyannx.ggmp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        startPanelNotification()
        showPanel()
    }

    private fun startPanelNotification() {
        val channelId = "rayyannx_panel"

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId,
                "RayyannX GGMP",
                NotificationManager.IMPORTANCE_LOW
            )

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("RayyannX GGMP")
                .setContentText("Floating Panel aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("RayyannX GGMP")
                .setContentText("Floating Panel aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }

        startForeground(1001, notification)
    }

    private fun showPanel() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(25, 30, 42))
        }

        val title = TextView(this).apply {
            text = "RAYYANNX GGMP"
            setTextColor(Color.rgb(181, 243, 77))
            textSize = 16f
            setPadding(8, 8, 8, 8)
        }

        val editButton = Button(this).apply {
            text = "EDIT MAPPING"
            setOnClickListener {
                title.text = "MODE EDIT MAPPING"
            }
        }

        val saveButton = Button(this).apply {
            text = "SIMPAN MAPPING"
            setOnClickListener {
                title.text = "MAPPING TERSIMPAN"
            }
        }

        val closeButton = Button(this).apply {
            text = "TUTUP PANEL"
            setOnClickListener {
                stopSelf()
            }
        }

        layout.addView(title)
        layout.addView(editButton)
        layout.addView(saveButton)
        layout.addView(closeButton)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 150
        }

        title.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(
                view: View,
                event: MotionEvent
            ): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX +
                            (event.rawX - touchX).toInt()

                        params.y = startY +
                            (event.rawY - touchY).toInt()

                        windowManager.updateViewLayout(layout, params)
                        return true
                    }
                }

                return false
            }
        })

        panel = layout
        windowManager.addView(layout, params)
    }

    override fun onDestroy() {
        panel?.let {
            if (it.isAttachedToWindow) {
                windowManager.removeView(it)
            }
        }

        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
