
package com.rayyannx.ggmp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, override val message: String) : Exception(message)

data class LoginResult(val token: String, val username: String, val plan: String)
data class SessionResult(val username: String, val plan: String)

object RayyannApi {
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private suspend fun request(
        path: String,
        method: String,
        payload: JSONObject? = null,
        token: String? = null
    ): JSONObject = withContext(Dispatchers.IO) {
        val url = AppConfig.BASE_URL.trimEnd('/') + "/$path"
        val builder = Request.Builder()
            .url(url)
            .header("Accept", "application/json")

        if (token != null) {
            builder.header("Authorization", "Bearer $token")
        }

        if (method == "POST") {
            builder.post(
                (payload ?: JSONObject()).toString().toRequestBody(jsonType)
            )
        } else {
            builder.get()
        }

        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val body = try {
                JSONObject(text)
            } catch (_: Exception) {
                JSONObject()
            }

            if (!response.isSuccessful) {
                val message = body.optString("message")
                    .ifBlank { "Server error (${response.code})" }
                throw ApiException(response.code, message)
            }
            body
        }
    }

    suspend fun login(
        username: String,
        password: String,
        licenseKey: String
    ): LoginResult {
        val body = request(
            "auth/login",
            "POST",
            JSONObject().apply {
                put("username", username.trim())
                put("password", password)
                put("licenseKey", licenseKey.trim())
            }
        )

        val user = body.optJSONObject("user") ?: JSONObject()
        val token = body.optString("token")
        val plan = body.optString("status")

        if (token.isBlank() || plan != "PREMIUM") {
            throw IOException("Login gagal: respons server bukan PREMIUM")
        }

        return LoginResult(
            token,
            user.optString("username", username),
            plan
        )
    }

    suspend fun checkSession(token: String): SessionResult {
        val body = request("auth/me", "GET", token = token)
        val user = body.optJSONObject("user") ?: JSONObject()
        val plan = body.optString("status")

        if (plan != "PREMIUM") {
            throw IOException("Status akun tidak valid")
        }

        return SessionResult(
            user.optString("username"),
            plan
        )
    }
}
