package com.rayyannx.ggmp

import android.content.Context

class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences("rayyannx_secure_session", Context.MODE_PRIVATE)

    fun saveToken(token: String) {
        val encrypted = SecureTokenStore.encrypt(token)
        check(prefs.edit().putString("token_ciphertext", encrypted).commit()) {
            "Could not persist session token"
        }
    }

    fun readToken(): String? {
        val encrypted = prefs.getString("token_ciphertext", null) ?: return null
        return try {
            SecureTokenStore.decrypt(encrypted)
        } catch (_: Exception) {
            clear()
            null
        }
    }

    fun clear() {
        prefs.edit().remove("token_ciphertext").commit()
    }
}
