package com.rayyannx.ggmp

object AppConfig {
    const val BASE_URL = "https://rayyannx-ggmp-backend-production.up.railway.app/"
}