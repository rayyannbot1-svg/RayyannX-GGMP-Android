
package com.rayyannx.ggmp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.IOException

private val bg = Color(0xFF10131C)
private val panel = Color(0xFF1C2230)
private val lime = Color(0xFFB5F34D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RayyannApp() }
    }
}

@Composable
fun RayyannApp() {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var logged by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var memberName by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Main Page") }

    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = bg,
            surface = panel,
            primary = lime,
            onPrimary = bg
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            if (!logged) {
                Column(
                    Modifier.fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        "RAYYANNX",
                        color = lime,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black
                    )

                    Text("GGMP • Account Login", color = Color.LightGray)

                    Spacer(Modifier.height(24.dp))

                    OutlinedTextField(
                        username,
                        { username = it },
                        label = { Text("Username") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        password,
                        { password = it },
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        key,
                        { key = it },
                        label = { Text("License Key") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )

                    if (error != null) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            error!!,
                            color = Color(0xFFFF7777),
                            fontSize = 13.sp
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            loading = true
                            error = null

                            scope.launch {
                                try {
                                    val result = RayyannApi.login(
                                        username,
                                        password,
                                        key
                                    )

                                    memberName = result.username
                                    logged = true
                                    password = ""
                                    key = ""

                                } catch (e: ApiException) {
                                    error = e.message
                                } catch (e: Exception) {
                                    error = when (e) {
                                        is IOException ->
                                            e.message ?: "Tidak dapat terhubung ke server."
                                        else ->
                                            e.message ?: "Login gagal. Coba lagi."
                                    }
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading &&
                            username.isNotBlank() &&
                            password.isNotBlank() &&
                            key.isNotBlank()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(
                                Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("LOGIN")
                        }
                    }

                    Text(
                        "Login diverifikasi oleh server RayyannX.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            "RAYYANNX",
                            color = lime,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            "PREMIUM MEMBER • $memberName",
                            color = lime
                        )
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Main Page", "Account", "More").forEach {
                            TextButton(onClick = { page = it }) {
                                Text(
                                    it,
                                    color = if (page == it) lime else Color.White
                                )
                            }
                        }
                    }

                    Column(
                        Modifier.weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(18.dp)
                    ) {
                        Text(
                            page,
                            color = lime,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(Modifier.height(12.dp))

                        val entries = when (page) {
                            "Main Page" ->
                                listOf("My Games", "Free Fire • Launch")

                            "Account" ->
                                listOf(
                                    "VIP • PREMIUM",
                                    "Gold",
                                    "Points Mall",
                                    "Premium Plan",
                                    "Redeem Code",
                                    "Daily Check-in"
                                )

                            else ->
                                listOf(
                                    "Activation Mode",
                                    "Activation Assistant",
                                    "Activate Another Device",
                                    "Customize Mouse Style",
                                    "Permissions Management",
                                    "Settings"
                                )
                        }

                        entries.forEach {
                            Card(
                                Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = panel
                                )
                            ) {
                                Text(
                                    it,
                                    Modifier.padding(18.dp),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    TextButton(
                        onClick = {
                            logged = false
                            memberName = ""
                            page = "Main Page"
                            error = null
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("LOG OUT", color = lime)
                    }
                }
            }
        }
    }
}

