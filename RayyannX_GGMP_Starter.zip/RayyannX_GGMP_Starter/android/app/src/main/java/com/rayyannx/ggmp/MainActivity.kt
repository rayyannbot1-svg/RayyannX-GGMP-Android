package com.rayyannx.ggmp

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch

private val bg = Color(0xFF10131C)
private val panel = Color(0xFF1C2230)
private val lime = Color(0xFFB5F34D)

data class InstalledApp(
    val name: String,
    val packageName: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RayyannApp() }
    }
}

@Composable
fun RayyannApp() {
    val context = LocalContext.current
    val activity = context as? ComponentActivity

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var logged by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var memberName by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Mulai Game") }
    var showApps by remember { mutableStateOf(false) }

    val selectedApps = remember { mutableStateListOf<InstalledApp>() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(logged) {
        activity?.requestedOrientation =
            if (logged) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = bg,
            surface = panel,
            primary = lime,
            onPrimary = bg
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = bg
        ) {
            if (!logged) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "RAYYANNX",
                        color = lime,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text("GGMP • Account Login", color = Color.LightGray)
                    Spacer(Modifier.height(24.dp))

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Username") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it },
                        label = { Text("License Key") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )

                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = Color(0xFFFF7777))
                    }
                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            loading = true
                            error = null
                            scope.launch {
                                try {
                                    val result = RayyannApi.login(username, password, key)
                                    memberName = result.username
                                    logged = true
                                    password = ""
                                    key = ""
                                } catch (e: ApiException) {
                                    error = e.message
                                } catch (e: Exception) {
                                    error = e.message ?: "Login gagal."
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading &&
                            username.isNotBlank() &&
                            password.isNotBlank() &&
                            key.isNotBlank()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("LOGIN")
                        }
                    }

                    Text(
                        "Login diverifikasi oleh server RayyannX.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Humanoid Team",
                            color = lime,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            "RAYYANNX GGMP",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "PREMIUM • $memberName",
                            color = lime,
                            fontSize = 13.sp
                        )
                    }

                    HorizontalDivider(color = Color.DarkGray)

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(20.dp)
                        ) {
                            when (page) {
                                "Mulai Game" -> {
                                    Text(
                                        "My Games",
                                        color = Color.White,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = { showApps = true }) {
                                        Text("+ Tambahkan Game")
                                    }
                                    Spacer(Modifier.height(16.dp))

                                    if (selectedApps.isEmpty()) {
                                        Text(
                                            "Belum ada aplikasi. Tekan Tambahkan Game.",
                                            color = Color.LightGray
                                        )
                                    }

                                    selectedApps.forEach { app ->
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(bottom = 14.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = panel
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(14.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                AppIcon(app.packageName)
                                                Spacer(Modifier.height(8.dp))
                                                Text(
                                                    app.name,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Spacer(Modifier.height(10.dp))
                                                Button(
                                                    onClick = {
                                                        context.packageManager
                                                            .getLaunchIntentForPackage(app.packageName)
                                                            ?.let { context.startActivity(it) }
                                                    },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("MULAI GAME")
                                                }
                                                TextButton(
                                                    onClick = { selectedApps.remove(app) }
                                                ) {
                                                    Text("Hapus dari My Games")
                                                }
                                            }
                                        }
                                    }
                                }

                                "Akun Saya" -> {
                                    Text(
                                        "Akun Saya",
                                        color = lime,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text("Akun: $memberName", color = Color.White)
                                    Text(
                                        "Status: PREMIUM",
                                        color = lime,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(14.dp))
                                    listOf(
                                        "VIP",
                                        "Gold",
                                        "Points Mall",
                                        "Premium Plan",
                                        "Redeem Code",
                                        "Daily Check-in",
                                        "Informasi Akun",
                                        "Masuk dengan Google"
                                    ).forEach { MenuCard(it) }
                                }

                                "Pengaturan" -> {
                                    Text(
                                        "Pengaturan",
                                        color = lime,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    listOf(
                                        "Owner: Rayyannkcung",
                                        "WhatsApp",
                                        "Telegram",
                                        "Instagram",
                                        "TikTok",
                                        "Versi Aplikasi",
                                        "Tentang RayyannX GGMP",
                                        "Kebijakan Privasi"
                                    ).forEach { MenuCard(it) }

                                    Spacer(Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            logged = false
                                            memberName = ""
                                            username = ""
                                            password = ""
                                            key = ""
                                            page = "Mulai Game"
                                            error = null
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF9C3333)
                                        )
                                    ) {
                                        Text("KELUAR AKUN")
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = Color.DarkGray)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(panel)
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Mulai Game", "Akun Saya", "Pengaturan").forEach { item ->
                            TextButton(onClick = { page = item }) {
                                Text(
                                    item,
                                    color = if (page == item) lime else Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            if (showApps) {
                val apps = remember {
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                    }
                    context.packageManager
                        .queryIntentActivities(intent, 0)
                        .map { info ->
                            InstalledApp(
                                info.loadLabel(context.packageManager).toString(),
                                info.activityInfo.packageName
                            )
                        }
                        .distinctBy { it.packageName }
                        .sortedBy { it.name.lowercase() }
                }

                AlertDialog(
                    onDismissRequest = { showApps = false },
                    containerColor = panel,
                    title = { Text("Pilih Aplikasi", color = lime) },
                    text = {
                        LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                            items(apps) { app ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (selectedApps.none {
                                                    it.packageName == app.packageName
                                                }
                                            ) {
                                                selectedApps.add(app)
                                            }
                                            showApps = false
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AppIcon(app.packageName, 36)
                                    Spacer(Modifier.width(12.dp))
                                    Text(app.name, color = Color.White)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showApps = false }) {
                            Text("TUTUP")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun AppIcon(packageName: String, size: Int = 64) {
    AndroidView(
        factory = { ctx ->
            ImageView(ctx).apply {
                layoutParams = android.view.ViewGroup.LayoutParams(size, size)
                scaleType = ImageView.ScaleType.FIT_CENTER
                try {
                    setImageDrawable(ctx.packageManager.getApplicationIcon(packageName))
                } catch (e: Exception) {
                    setImageResource(android.R.drawable.sym_def_app_icon)
                }
            }
        },
        modifier = Modifier.size(size.dp)
    )
}

@Composable
fun MenuCard(title: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = panel)
    ) {
        Text(
            text = title,
            color = Color.White,
            modifier = Modifier.padding(16.dp),
            fontWeight = FontWeight.Medium
        )
    }
}
