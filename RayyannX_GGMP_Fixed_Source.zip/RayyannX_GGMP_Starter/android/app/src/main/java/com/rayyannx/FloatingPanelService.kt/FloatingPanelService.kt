
package com.rayyannx.ggmp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private lateinit var mappingArea: LinearLayout
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams

    private val keys = mutableListOf<String>()

    private val keyOptions = listOf(
        "W", "A", "S", "D",
        "SPACE", "FIRE", "RELOAD",
        "JUMP", "CROUCH", "SCOPE"
    )

    override fun onCreate() {
        super.onCreate()

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        startPanelNotification()
        showFloatingBubble()
    }

    private fun showFloatingBubble() {
        if (bubble?.isAttachedToWindow == true) return
        val badge = TextView(this).apply {
            text = "RX"
            textSize = 17f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(181, 243, 77))
                setStroke(3, Color.WHITE)
            }
            elevation = 12f
        }
        val lp = WindowManager.LayoutParams(
            58, 58,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
        bubbleParams = lp
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        badge.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    try { windowManager.updateViewLayout(badge, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) showPanel()
                    true
                }
                else -> true
            }
        }
        bubble = badge
        try { windowManager.addView(badge, lp) } catch (e: Exception) { bubble = null; stopSelf() }
    }

    private fun removeBubble() {
        bubble?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        bubble = null
    }

    private fun startPanelNotification() {
        val channelId = "rayyannx_panel"

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId,
                "RayyannX GGMP",
                NotificationManager.IMPORTANCE_LOW
            )

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("RayyannX GGMP")
                .setContentText("Gaming Mapping Engine")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("RayyannX GGMP")
                .setContentText("Gaming Mapping Engine")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }

        startForeground(1001, notification)
    }

    private fun rounded(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = 18f
        }
    }

    private fun text(
        value: String,
        size: Float = 14f,
        color: Int = Color.WHITE
    ): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    private fun makeButton(
        value: String,
        color: Int = Color.rgb(42, 49, 65),
        action: () -> Unit
    ): Button {
        return Button(this).apply {
            text = value
            textSize = 11f
            setTextColor(Color.WHITE)
            background = rounded(color)
            setOnClickListener { action() }
        }
    }

    private fun showPanel() {
        if (panel?.isAttachedToWindow == true) return
        removeBubble()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 14)
            background = rounded(Color.rgb(15, 18, 27))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = text(
            "RX  RAYYANNX GGMP",
            16f,
            Color.rgb(181, 243, 77)
        )

        header.addView(
            title,
            LinearLayout.LayoutParams(0, 48, 1f)
        )

        val minimize = makeButton("MIN", Color.rgb(45, 55, 72)) {
            panel?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
            panel = null
            showFloatingBubble()
        }

        header.addView(minimize)

        header.addView(
            makeButton("X", Color.rgb(150, 35, 45)) {
                stopSelf()
            }
        )

        root.addView(header)

        val editor = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 12, 8, 8)
            background = rounded(Color.rgb(27, 33, 46))
        }

        editor.addView(
            text("MAPPING EDITOR", 15f, Color.rgb(181, 243, 77))
        )

        editor.addView(
            text("Pilih tombol untuk membuat konfigurasi", 11f)
        )

        mappingArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 12, 4, 12)
        }

        editor.addView(mappingArea)

        val addTitle = text(
            "TAMBAH TOMBOL",
            12f,
            Color.rgb(181, 243, 77)
        )

        editor.addView(addTitle)

        val keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        listOf("W", "A", "S", "D", "SPACE").forEach { key ->
            keyRow.addView(
                makeButton(key) {
                    addMapping(key)
                },
                LinearLayout.LayoutParams(0, 48, 1f)
            )
        }

        editor.addView(keyRow)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        listOf("FIRE", "RELOAD", "JUMP").forEach { key ->
            actionRow.addView(
                makeButton(key) {
                    addMapping(key)
                },
                LinearLayout.LayoutParams(0, 48, 1f)
            )
        }

        editor.addView(actionRow)

        root.addView(editor)

        val mouseSettings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 12, 8, 8)
            background = rounded(Color.rgb(27, 33, 46))
        }

        mouseSettings.addView(
            text("MOUSE SETTINGS", 14f, Color.rgb(181, 243, 77))
        )

        val sensitivityLabel = text("Sensitivitas: 50%", 12f)

        mouseSettings.addView(sensitivityLabel)

        val sensitivity = SeekBar(this).apply {
            max = 100
            progress = 50

            setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(
                        seekBar: SeekBar?,
                        progress: Int,
                        fromUser: Boolean
                    ) {
                        sensitivityLabel.text =
                            "Sensitivitas: $progress%"
                    }

                    override fun onStartTrackingTouch(
                        seekBar: SeekBar?
                    ) {}

                    override fun onStopTrackingTouch(
                        seekBar: SeekBar?
                    ) {}
                }
            )
        }

        mouseSettings.addView(sensitivity)
        root.addView(mouseSettings)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        bottom.addView(
            makeButton("SIMPAN MAPPING", Color.rgb(75, 115, 45)) {
                saveMapping()
            },
            LinearLayout.LayoutParams(0, 48, 1f)
        )

        bottom.addView(
            makeButton("RESET", Color.rgb(120, 45, 45)) {
                keys.clear()
                mappingArea.removeAllViews()
                Toast.makeText(
                    this,
                    "Mapping editor direset",
                    Toast.LENGTH_SHORT
                ).show()
            },
            LinearLayout.LayoutParams(0, 48, 1f)
        )

        root.addView(bottom)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 25
            y = 100
        }

        header.setOnTouchListener(
            object : View.OnTouchListener {
                private var startX = 0
                private var startY = 0
                private var touchX = 0f
                private var touchY = 0f

                override fun onTouch(
                    view: View,
                    event: MotionEvent
                ): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = params.x
                            startY = params.y
                            touchX = event.rawX
                            touchY = event.rawY
                            return true
                        }

                        MotionEvent.ACTION_MOVE -> {
                            params.x = startX +
                                (event.rawX - touchX).toInt()

                            params.y = startY +
                                (event.rawY - touchY).toInt()

                            windowManager.updateViewLayout(
                                root,
                                params
                            )
                            return true
                        }
                    }

                    return false
                }
            }
        )

        panel = root
        windowManager.addView(root, params)

        loadMapping()
    }

    private fun addMapping(key: String) {
        if (keys.contains(key)) {
            Toast.makeText(
                this,
                "$key sudah ditambahkan",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        keys.add(key)

        val item = TextView(this).apply {
            text = "  $key     ×"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
            background = rounded(Color.rgb(45, 65, 85))

            setOnClickListener {
                keys.remove(key)
                mappingArea.removeView(this)
            }
        }

        mappingArea.addView(
            item,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                42
            ).apply {
                bottomMargin = 5
            }
        )
    }

    private fun saveMapping() {
        getSharedPreferences(
            "rayyannx_mapping",
            MODE_PRIVATE
        ).edit()
            .putStringSet("keys", keys.toSet())
            .apply()

        Toast.makeText(
            this,
            "Konfigurasi mapping disimpan",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun loadMapping() {
        val saved = getSharedPreferences(
            "rayyannx_mapping",
            MODE_PRIVATE
        ).getStringSet("keys", emptySet()) ?: emptySet()

        keys.clear()

        saved.forEach { key ->
            addMapping(key)
        }
    }

    override fun onDestroy() {
        panel?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        bubble?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
